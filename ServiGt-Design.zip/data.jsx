// Shared mock data + tiny helpers for ServiGT.
// All Spanish (es-GT). Quetzal prices, Guatemalan zones.

const SGT_CATEGORIES = [
  { id: 'plomeria',   name: 'Plomería',          icon: 'Wrench',         color: '#1a73e8', count: 142 },
  { id: 'electricidad', name: 'Electricidad',    icon: 'Zap',            color: '#f59e0b', count: 118 },
  { id: 'limpieza',   name: 'Limpieza',          icon: 'Sparkles',       color: '#16a34a', count: 203 },
  { id: 'jardineria', name: 'Jardinería',        icon: 'Trees',          color: '#15803d', count: 67  },
  { id: 'ninera',     name: 'Niñera',            icon: 'Baby',           color: '#db2777', count: 89  },
  { id: 'tecnico',    name: 'Técnico en PC',     icon: 'Laptop',         color: '#7c3aed', count: 54  },
  { id: 'albanileria',name: 'Albañilería',       icon: 'Hammer',         color: '#dc2626', count: 76  },
  { id: 'otros',      name: 'Otros servicios',   icon: 'MoreHorizontal', color: '#667085', count: 48  },
];

const SGT_ZONES = [
  'Zona 1','Zona 4','Zona 9','Zona 10','Zona 11','Zona 13','Zona 14','Zona 15','Zona 16',
  'Mixco','Villa Nueva','Villa Canales','San Miguel Petapa','Antigua Guatemala',
  'San Lucas Sacatepéquez','Carretera a El Salvador','Santa Catarina Pinula',
];

// Stable Unsplash portrait IDs (faces). Used as avatars.
const SGT_FACES = [
  'photo-1507003211169-0a1dd7228f2d', // hombre
  'photo-1494790108377-be9c29b29330', // mujer
  'photo-1500648767791-00dcc994a43e', // hombre
  'photo-1438761681033-6461ffad8d80', // mujer
  'photo-1472099645785-5658abf4ff4e', // hombre
  'photo-1544005313-94ddf0286df2',    // mujer
  'photo-1519085360753-af0119f7cbe7', // hombre
  'photo-1573496359142-b8d87734a5a2', // mujer
  'photo-1463453091185-61582044d556', // hombre
  'photo-1545996124-0501ebae84d0',    // mujer
  'photo-1492562080023-ab3db95bfbce', // hombre
  'photo-1534528741775-53994a69daeb', // mujer
];

const sgtFace = (i, w = 200) =>
  `https://images.unsplash.com/${SGT_FACES[i % SGT_FACES.length]}?w=${w}&h=${w}&fit=crop&crop=faces`;

// Work / gallery photos by category (stable Unsplash IDs).
const SGT_WORK_PHOTOS = {
  plomeria:    ['photo-1585704032915-c3400ca199e7','photo-1542013936693-884638332954','photo-1607472586893-edb57bdc0e39'],
  electricidad:['photo-1565608438257-fac3c27beb36','photo-1621905251189-08b45d6a269e','photo-1473341304170-971dccb5ac1e'],
  limpieza:    ['photo-1581578731548-c64695cc6952','photo-1527515637462-cff94eecc1ac','photo-1584622650111-993a426fbf0a'],
  jardineria:  ['photo-1416879595882-3373a0480b5b','photo-1558904541-efa843a96f01','photo-1523348837708-15d4a09cfac2'],
  ninera:      ['photo-1503454537195-1dcabb73ffb9','photo-1587616211892-f743fcca64f9','photo-1607582544095-2c3d5c40d0fb'],
  tecnico:     ['photo-1550009158-9ebf69173e03','photo-1547082299-de196ea013d6','photo-1518770660439-4636190af475'],
  albanileria: ['photo-1503387762-592deb58ef4e','photo-1504307651254-35680f356dfd','photo-1581094794329-c8112a89af12'],
  otros:       ['photo-1581578731548-c64695cc6952','photo-1521791136064-7986c2920216','photo-1454165804606-c3d57bc86b40'],
};
const sgtWork = (cat, i, w = 600) => {
  const list = SGT_WORK_PHOTOS[cat] || SGT_WORK_PHOTOS.otros;
  return `https://images.unsplash.com/${list[i % list.length]}?w=${w}&q=70&auto=format&fit=crop`;
};

const SGT_PROVIDERS = [
  { id: 'p1', name: 'Carlos Méndez',     cat: 'plomeria',     zone: 'Zona 10',          rating: 4.9, reviews: 128, priceFrom: 150, exp: 8,  verified: true,  available: true,  bio: 'Plomero certificado con experiencia en residencial y comercial. Trabajos garantizados.', services: [{ name: 'Reparación de fugas', price: 150 },{ name: 'Instalación de grifería', price: 220 },{ name: 'Destape de cañerías', price: 280 },{ name: 'Cambio de tubería', price: 450 }] },
  { id: 'p2', name: 'María Fernanda López', cat: 'limpieza',  zone: 'Mixco',            rating: 4.8, reviews: 214, priceFrom: 120, exp: 5,  verified: true,  available: true,  bio: 'Limpieza profunda de casas y oficinas. Productos ecológicos disponibles.', services: [{ name: 'Limpieza general (4h)', price: 250 },{ name: 'Limpieza profunda', price: 480 },{ name: 'Limpieza post-obra', price: 650 }] },
  { id: 'p3', name: 'Luis Alberto Ramírez', cat: 'electricidad', zone: 'Zona 14',       rating: 4.7, reviews: 96,  priceFrom: 200, exp: 12, verified: true,  available: false, bio: 'Electricista industrial y residencial. Diagnóstico sin costo.', services: [{ name: 'Diagnóstico eléctrico', price: 0 },{ name: 'Instalación de tomacorriente', price: 180 },{ name: 'Cambio de tablero', price: 850 }] },
  { id: 'p4', name: 'Ana Lucía Estrada',  cat: 'ninera',       zone: 'Antigua Guatemala', rating: 5.0, reviews: 47,  priceFrom: 80,  exp: 6,  verified: true,  available: true,  bio: 'Niñera con formación en pedagogía. Disponible fines de semana.', services: [{ name: 'Cuidado por hora', price: 80 },{ name: 'Día completo', price: 450 }] },
  { id: 'p5', name: 'Diego Morales',      cat: 'tecnico',      zone: 'Zona 11',         rating: 4.6, reviews: 73,  priceFrom: 175, exp: 4,  verified: false, available: true,  bio: 'Reparación de PCs y laptops. Recuperación de datos.', services: [{ name: 'Mantenimiento básico', price: 175 },{ name: 'Formateo + instalación', price: 320 },{ name: 'Recuperación de datos', price: 600 }] },
  { id: 'p6', name: 'Sofía Hernández',    cat: 'jardineria',   zone: 'Carretera a El Salvador', rating: 4.9, reviews: 58, priceFrom: 200, exp: 7, verified: true, available: true,  bio: 'Diseño y mantenimiento de jardines. Podas y riego automatizado.', services: [{ name: 'Mantenimiento mensual', price: 600 },{ name: 'Diseño de jardín', price: 2500 }] },
  { id: 'p7', name: 'Roberto Castillo',   cat: 'albanileria',  zone: 'Villa Nueva',     rating: 4.5, reviews: 89,  priceFrom: 350, exp: 15, verified: true,  available: false, bio: 'Albañil maestro. Remodelaciones, ampliaciones y acabados finos.', services: [{ name: 'Reparación de muros', price: 350 },{ name: 'Remodelación de baño', price: 6500 }] },
  { id: 'p8', name: 'Patricia Gómez',     cat: 'limpieza',     zone: 'Zona 15',         rating: 4.8, reviews: 142, priceFrom: 130, exp: 9,  verified: true,  available: true,  bio: 'Equipo de limpieza profesional para residencias.', services: [{ name: 'Limpieza por hora', price: 130 }] },
];

// Index providers by id for easy lookup
const SGT_PROVIDERS_BY_ID = Object.fromEntries(SGT_PROVIDERS.map((p, i) => [p.id, { ...p, faceIdx: i }]));

const SGT_REVIEWS = [
  { provider: 'p1', author: 'Jorge M.',  rating: 5, date: 'Hace 3 días',   text: 'Excelente trabajo, llegó puntual y dejó todo limpio. Muy recomendado.', faceIdx: 0 },
  { provider: 'p1', author: 'Luisa P.',  rating: 5, date: 'Hace 1 semana', text: 'Resolvió la fuga en 30 minutos. Precio justo.', faceIdx: 1 },
  { provider: 'p1', author: 'Andrés C.', rating: 4, date: 'Hace 2 semanas', text: 'Buen trabajo aunque llegó 15 min tarde.', faceIdx: 2 },
  { provider: 'p2', author: 'Karla R.',  rating: 5, date: 'Hace 5 días',   text: 'Dejó la casa impecable. Volveré a contratarla.', faceIdx: 3 },
];

const SGT_REQUESTS = [
  { id: 'r1', service: 'Reparación de fuga en cocina',   provider: 'p1', date: '04 May, 2026 · 14:00', status: 'pendiente',  amount: 220, address: 'Zona 10, 6a Av' },
  { id: 'r2', service: 'Limpieza profunda mensual',      provider: 'p2', date: '02 May, 2026 · 09:00', status: 'aceptada',   amount: 480, address: 'Mixco, Col. Las Brisas' },
  { id: 'r3', service: 'Instalación de tomacorrientes',  provider: 'p3', date: '28 Abr, 2026 · 10:30', status: 'en_curso',   amount: 540, address: 'Zona 14, Edificio Tikal' },
  { id: 'r4', service: 'Cuidado de niño 8h',             provider: 'p4', date: '20 Abr, 2026 · 08:00', status: 'completada', amount: 450, address: 'Antigua, 5a Calle Oriente' },
  { id: 'r5', service: 'Mantenimiento de jardín',        provider: 'p6', date: '15 Abr, 2026 · 07:00', status: 'completada', amount: 600, address: 'Km 14.5 Carr. a El Salvador' },
  { id: 'r6', service: 'Formateo de laptop',             provider: 'p5', date: '10 Abr, 2026 · 16:00', status: 'cancelada',  amount: 320, address: 'Zona 11, Col. Mariscal' },
];

const SGT_STATUS = {
  pendiente:  { label: 'Pendiente',  bg: '#fff7e6', fg: '#b45309', dot: '#f59e0b' },
  aceptada:   { label: 'Aceptada',   bg: '#e8f1ff', fg: '#1a73e8', dot: '#4ea8ff' },
  en_curso:   { label: 'En curso',   bg: '#dbeafe', fg: '#0b3d91', dot: '#1a73e8' },
  completada: { label: 'Completada', bg: '#dcfce7', fg: '#166534', dot: '#16a34a' },
  cancelada:  { label: 'Cancelada',  bg: '#fee2e2', fg: '#991b1b', dot: '#dc2626' },
};

const SGT_NOTIFS = [
  { id: 'n1', group: 'hoy',      type: 'request', title: 'Nueva solicitud de servicio',  body: 'Carlos M. te envió una solicitud de plomería en Zona 10', time: 'Hace 12 min', unread: true,  icon: 'Bell' },
  { id: 'n2', group: 'hoy',      type: 'message', title: 'Mensaje nuevo',                 body: 'María Fernanda: "Hola, ¿podemos confirmar la hora?"',          time: 'Hace 1 h',  unread: true,  icon: 'MessageCircle' },
  { id: 'n3', group: 'hoy',      type: 'review',  title: 'Nueva reseña 5 ★',             body: 'Jorge M. dejó una reseña en tu perfil',                        time: 'Hace 3 h',  unread: false, icon: 'Star' },
  { id: 'n4', group: 'semana',   type: 'payment', title: 'Pago recibido',                 body: 'Recibiste Q480 por el servicio del 02 de mayo',                time: 'Lun 14:22', unread: false, icon: 'CreditCard' },
  { id: 'n5', group: 'semana',   type: 'request', title: 'Solicitud completada',          body: 'La solicitud #r3 fue marcada como completada',                 time: 'Mar 09:15', unread: false, icon: 'CheckCircle2' },
  { id: 'n6', group: 'anteriores', type: 'system', title: 'Tu perfil fue verificado',     body: 'Felicidades, ahora apareces como Verificado',                  time: '14 Abr',    unread: false, icon: 'ShieldCheck' },
  { id: 'n7', group: 'anteriores', type: 'message', title: 'Mensaje nuevo',                body: 'Diego M.: "Adjunto la cotización"',                            time: '08 Abr',    unread: false, icon: 'MessageCircle' },
];

const SGT_CHATS = [
  { id: 'c1', with: 'p1', last: 'Perfecto, llego en 20 min', time: '14:32', unread: 2,  status: 'aceptada' },
  { id: 'c2', with: 'p2', last: 'Adjunto fotos de la casa',   time: '11:08', unread: 0,  status: 'pendiente' },
  { id: 'c3', with: 'p4', last: 'Gracias por confirmar',      time: 'Ayer',  unread: 0,  status: 'completada' },
  { id: 'c4', with: 'p6', last: 'Llevo el equipo de poda',    time: 'Lun',   unread: 1,  status: 'en_curso' },
  { id: 'c5', with: 'p5', last: 'OK, lo veo mañana',          time: '28 Abr', unread: 0, status: 'aceptada' },
];

const SGT_MESSAGES = {
  c1: [
    { from: 'them', text: 'Hola, recibí tu solicitud de fuga en cocina', time: '14:18', read: true },
    { from: 'me',   text: '¡Hola Carlos! ¿Podrías venir hoy en la tarde?', time: '14:20', read: true },
    { from: 'them', text: 'Sí, tengo disponible a las 14:30', time: '14:22', read: true },
    { from: 'me',   text: 'Perfecto, te dejo la dirección', time: '14:25', read: true },
    { from: 'me',   text: 'Zona 10, 6a Av 12-34', time: '14:25', read: true },
    { from: 'them', text: 'Recibido. Llevo herramienta para soldar también', time: '14:28', read: true },
    { from: 'them', text: 'Perfecto, llego en 20 min', time: '14:32', read: false },
  ],
  c2: [
    { from: 'them', text: 'Hola, ¿qué tipo de limpieza necesitas?', time: '10:45', read: true },
    { from: 'me',   text: 'Limpieza profunda, casa de 3 ambientes', time: '10:50', read: true },
    { from: 'them', text: 'Adjunto fotos de la casa',                 time: '11:08', read: false },
  ],
};

// Dashboard time series
const SGT_INCOME_6M = [
  { month: 'Nov', value: 4200 },
  { month: 'Dic', value: 5800 },
  { month: 'Ene', value: 5100 },
  { month: 'Feb', value: 6400 },
  { month: 'Mar', value: 7200 },
  { month: 'Abr', value: 8650 },
];

const SGT_REQ_BY_MONTH = [
  { month: 'Nov', value: 142 },
  { month: 'Dic', value: 198 },
  { month: 'Ene', value: 175 },
  { month: 'Feb', value: 234 },
  { month: 'Mar', value: 289 },
  { month: 'Abr', value: 327 },
];

const SGT_REQ_BY_CAT = [
  { name: 'Limpieza',     value: 32, color: '#16a34a' },
  { name: 'Plomería',     value: 22, color: '#1a73e8' },
  { name: 'Electricidad', value: 18, color: '#f59e0b' },
  { name: 'Jardinería',   value: 11, color: '#15803d' },
  { name: 'Niñera',       value: 9,  color: '#db2777' },
  { name: 'Otros',        value: 8,  color: '#667085' },
];

const SGT_PENDING_VERIF = [
  { id: 'pv1', name: 'Esteban Rodríguez', cat: 'electricidad', zone: 'Zona 9',  applied: '02 May', faceIdx: 4 },
  { id: 'pv2', name: 'Wendy Castañeda',  cat: 'limpieza',     zone: 'Mixco',   applied: '02 May', faceIdx: 5 },
  { id: 'pv3', name: 'José Pérez',        cat: 'albanileria',  zone: 'Villa Nueva', applied: '01 May', faceIdx: 6 },
  { id: 'pv4', name: 'Carmen Velásquez', cat: 'ninera',       zone: 'Zona 14', applied: '30 Abr', faceIdx: 7 },
];

const SGT_ZONE_HEAT = [
  { zone: 'Zona 10', value: 287 },
  { zone: 'Zona 14', value: 234 },
  { zone: 'Mixco',   value: 198 },
  { zone: 'Zona 15', value: 176 },
  { zone: 'Villa Nueva', value: 152 },
  { zone: 'Zona 11', value: 128 },
  { zone: 'Antigua', value: 94 },
  { zone: 'Zona 4',  value: 67 },
];

Object.assign(window, {
  SGT_CATEGORIES, SGT_ZONES, SGT_FACES, sgtFace, sgtWork, SGT_WORK_PHOTOS,
  SGT_PROVIDERS, SGT_PROVIDERS_BY_ID, SGT_REVIEWS, SGT_REQUESTS, SGT_STATUS,
  SGT_NOTIFS, SGT_CHATS, SGT_MESSAGES,
  SGT_INCOME_6M, SGT_REQ_BY_MONTH, SGT_REQ_BY_CAT, SGT_PENDING_VERIF, SGT_ZONE_HEAT,
});
